<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://hdc.net
 * @since             0.0.1
 * @package           EveryAlt
 *
 * @wordpress-plugin
 * Plugin Name:       EveryAlt
 * Plugin URI:        https://everyalt.com
 * Description:       Instantly generate alternative text for all your images.
 * Version:           1.0.2
 * Author:            HDC
 * Author URI:        https://hdc.net
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       everyalt
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Check for updates from GitHub (private update server).
 * Runs on every load so update notifications are visible to the dashboard and to management tools (e.g. WP-CLI).
 */
$everyalt_puc = plugin_dir_path( __FILE__ ) . 'vendor/plugin-update-checker/plugin-update-checker.php';
if ( file_exists( $everyalt_puc ) ) {
	require_once $everyalt_puc;
	$everyalt_updater = \YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
		'https://github.com/EveryAlt/everyalt-wordpress-plugin',
		__FILE__,
		'everyalt'
	);
	$everyalt_updater->getVcsApi()->enableReleaseAssets();
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'EVERY_ALT_VERSION', '1.0.2' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-everyalt-activator.php
 */
function activate_every_alt() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-everyalt-activator.php';
	Every_Alt_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-everyalt-deactivator.php
 */
function deactivate_every_alt() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-everyalt-deactivator.php';
	Every_Alt_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_every_alt' );
register_deactivation_hook( __FILE__, 'deactivate_every_alt' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-everyalt.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_every_alt() {

	$plugin = new Every_Alt();
	$plugin->run();

}
run_every_alt();
