<?php
/**
 * Media edit page: simple "Generate alt" button (no Vue/React).
 *
 * @package EveryAlt
 * @subpackage EveryAlt/admin/partials
 */
?>
<div id="everyalt-custom-media-button" class="everyalt-media-button-wrap" style="margin-top:12px;padding-left:12px;padding-right:12px;">
	<!-- Button and message injected by everyalt-media-simple.js -->
</div>
